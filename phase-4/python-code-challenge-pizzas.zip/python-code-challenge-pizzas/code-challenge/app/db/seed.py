from flask import Flask
from app import db
from app.db.models import Restaurant, Pizza

def seed_data():
    with app.app_context():
        db.create_all()

        restaurant1 = Restaurant(name='Restaurant A')
        restaurant2 = Restaurant(name='Restaurant B')
        pizza1 = Pizza(name='Pizza 1')
        pizza2 = Pizza(name='Pizza 2')

        db.session.add(restaurant1)
        db.session.add(restaurant2)
        db.session.add(pizza1)
        db.session.add(pizza2)
        db.session.commit()

        restaurant1.pizzas.append(pizza1)
        restaurant1.pizzas.append(pizza2)
        restaurant2.pizzas.append(pizza1)
        db.session.commit()

if __name__ == '__main__':
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db/seed.db'
    '  
    db.init_app(app)
    seed_data()

