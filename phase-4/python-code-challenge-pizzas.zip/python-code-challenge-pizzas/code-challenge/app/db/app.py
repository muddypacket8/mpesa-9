from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db/app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
migrate = Migrate(app, db)

class Restaurant(db.Model):
    # Define your Restaurant model here
    pass

@app.route('/')
def home():
    return ''

if __name__ == '__main__':
    app.run(port=5555)

