from flask_migrate import Migrate
from flask import Flask
from app.db.models import db

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///migrate.db'

db.init_app(app)
migrate = Migrate(app, db)

