from flask_sqlalchemy import SQLAlchemy
from flask import Flask, jsonify, request
from marshmallow import Schema, fields, validate


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db/models.db'
db = SQLAlchemy(app)

class Restaurant(db.Model):
    __tablename__ = 'restaurant'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    pizzas = db.relationship('Pizza', secondary='restaurant_pizza', backref='restaurants')

    def __repr__(self):
        return f'<Restaurant {self.name}>'

class Pizza(db.Model):
    __tablename__ ='Pizza'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)

class RestaurantPizza(db.Model):
    __tablename__ = 'Restaurant_Pizza'

    id = db.Column(db.Integer, primary_key=True)
    restaurant_id = db.Column(db.Integer, db.ForeignKey('restaurant.id'), nullable=False)
    pizza_id = db.Column(db.Integer, db.ForeignKey('pizza.id'), nullable=False)
    price = db.Column(db.Float, nullable=False)

class RestaurantPizzaSchema(Schema):
    id = fields.Int(dump_only=True)
    restaurant_id = fields.Int(required=True)
    pizza_id = fields.Int(required=True)
    price = fields.Float(required=True, validate=validate.Range(min=1, max=30))

# Create a new RestaurantPizza
@app.route('/restaurant_pizza', methods=['POST'])
def create_restaurant_pizza():
    restaurant_pizza_schema = RestaurantPizzaSchema()
    try:
        restaurant_pizza = restaurant_pizza_schema.load(request.json)
        db.session.add(restaurant_pizza)
        db.session.commit()
        return jsonify({'message': 'RestaurantPizza created successfully.'}), 201
    except ValidationError as err:
        return jsonify({'error': err.messages}), 400

# Get all RestaurantPizzas
@app.route('/restaurant_pizza', methods=['GET'])
def get_all_restaurant_pizzas():
    restaurant_pizzas = RestaurantPizza.query.all()
    restaurant_pizza_schema = RestaurantPizzaSchema(many=True)
    result = restaurant_pizza_schema.dump(restaurant_pizzas)
    return jsonify(result)

@app.route('/restaurants', methods=['GET'])
def get_restaurants():
    # Retrieve all restaurants from the database
    restaurants = Restaurant.query.all()
    
    # Convert the restaurants data to the desired JSON format
    restaurants_data = []
    for restaurant in restaurants:
        restaurant_data = {
            'id': restaurant.id,
            'name': restaurant.name,
            'address': restaurant.address
        }
        restaurants_data.append(restaurant_data)
    
    # Return the JSON data
    return jsonify(restaurants_data)

@app.route('/restaurants/<int:id>', methods=['GET'])
def get_restaurant(id):
    # Retrieve the restaurant with the given id from the database
    restaurant = Restaurant.query.get(id)
    
    if restaurant:
        # Retrieve the pizzas associated with the restaurant
        pizzas = restaurant.pizzas
        
        # Convert the restaurant and pizzas data to the desired JSON format
        restaurant_data = {
            'id': restaurant.id,
            'name': restaurant.name,
            'address': restaurant.address,
            'pizzas': []
        }
        for pizza in pizzas:
            pizza_data = {
                'id': pizza.id,
                'name': pizza.name,
                'ingredients': pizza.ingredients
            }
            restaurant_data['pizzas'].append(pizza_data)
        
        # Return the JSON data
        return jsonify(restaurant_data)
    else:
        # Return the error message if the restaurant is not found
        return jsonify({'error': 'Restaurant not found'}), 404

@app.route('/restaurants/<int:id>', methods=['DELETE'])
def delete_restaurant(id):
    # Retrieve the restaurant with the given id from the database
    restaurant = Restaurant.query.get(id)
    
    if restaurant:
        # Delete the associated restaurant pizzas
        RestaurantPizza.query.filter_by(restaurant_id=id).delete()
        
        # Delete the restaurant
        db.session.delete(restaurant)
        db.session.commit()
        
        # Return an empty response
        return '', 204
    else:
        # Return the error message if the restaurant is not found
        return jsonify({'error': 'Restaurant not found'}), 404

@app.route('/pizzas', methods=['GET'])
def get_pizzas():
    # Retrieve all pizzas from the database
    pizzas = Pizza.query.all()
    
    # Convert the pizzas data to the desired JSON format
    pizzas_data = []
    for pizza in pizzas:
        pizza_data = {
            'id': pizza.id,
            'name': pizza.name,
            'ingredients': pizza.ingredients
        }
        pizzas_data.append(pizza_data)
    
    # Return the JSON data
    return jsonify(pizzas_data)

@app.route('/restaurant_pizzas', methods=['POST'])
def create_restaurant_pizza():
    # Get the data from the request body
    data = request.json
    
    # Extract the required properties
    price = data.get('price')
    pizza_id = data.get('pizza_id')
    restaurant_id = data.get('restaurant_id')
    
    # Validate the price
    if price is None or not 1 <= price <= 30:
        return jsonify({'errors': ['Validation errors']}), 400
    
    # Create a new RestaurantPizza instance
    restaurant_pizza = RestaurantPizza(price=price, pizza_id=pizza_id, restaurant_id=restaurant_id)
    
    try:
        # Add the new restaurant pizza to the database
        db.session.add(restaurant_pizza)
        db.session.commit()
        
        # Retrieve the pizza associated with the restaurant pizza
        pizza = restaurant_pizza.pizza
        
        # Convert the pizza data to the desired JSON format
        pizza_data = {
            'id': pizza.id,
            'name': pizza.name,
            'ingredients': pizza.ingredients
        }
        
        # Return the JSON data
        return jsonify(pizza_data), 201
    except Exception as e:
        # Handle any exceptions and return the error message
        return jsonify({'errors': [str(e)]}), 500

if __name__ == '__main__':
    app.run()